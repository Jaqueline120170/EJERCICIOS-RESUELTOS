package servicios;

public interface MenuInterfaz {
	public int mostrarMenuYSeleccion();
	public void seleccionGestionBiblioteca();
}
